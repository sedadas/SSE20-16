package at.ac.tuwien.sse.owaspm5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import at.ac.tuwien.sse.owaspm5.entities.CreditCardInfo;
import at.ac.tuwien.sse.owaspm5.exceptions.InternalStorageException;
import at.ac.tuwien.sse.owaspm5.manager.ICreditCardStorageManager;
import at.ac.tuwien.sse.owaspm5.manager.IEncryptionManager;
import at.ac.tuwien.sse.owaspm5.manager.InternalCreditCardStorageManager;
import at.ac.tuwien.sse.owaspm5.manager.OwnEncryptionManager;

public class MainActivity extends AppCompatActivity {

    private IEncryptionManager encryptionManager;
    private ICreditCardStorageManager creditCardStorageManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Context context = this;

        encryptionManager = new OwnEncryptionManager();

        try {
            creditCardStorageManager = new InternalCreditCardStorageManager(this);
        } catch (InternalStorageException internalStorageException) {
            this.finishAndRemoveTask();
        }
        creditCardStorageManager.setEncryptionManager(encryptionManager);

        // If there are no stored credit card information, the EnterCreditCardInformationActivity
        // gets shown.
        if (!creditCardStorageManager.hasStoredCreditCardInformation()) {
            Intent intent = new Intent(MainActivity.this, EnterCreditCardInformationActivity.class);
            MainActivity.this.startActivity(intent);
        }

        final TextView textViewCreditCardInformation = findViewById(R.id.tvCreditCardInformation);
        final EditText editTextPassword = findViewById(R.id.etDecryptPassword);
        final Button buttonShow = findViewById(R.id.btnShow);
        Button buttonDelete = findViewById(R.id.btnDelete);

        // If the 'Show'-button is pressed and the provided password is corred, the stored credit
        // card information gets shown.
        buttonShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = editTextPassword.getText().toString();

                CreditCardInfo info = creditCardStorageManager.load(password);
                if (info == null) {
                    textViewCreditCardInformation.setText("");

                    Toast toast = Toast.makeText(context, "Wrong password provided!", Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }
                textViewCreditCardInformation.setText(info.toString());
            }
        });

        // If the 'Delete'-button is pressed, the stored credit card information gets deleted.
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                creditCardStorageManager.delete();
                Intent intent = new Intent(MainActivity.this, EnterCreditCardInformationActivity.class);
                MainActivity.this.startActivity(intent);
            }
        });
    }
}
