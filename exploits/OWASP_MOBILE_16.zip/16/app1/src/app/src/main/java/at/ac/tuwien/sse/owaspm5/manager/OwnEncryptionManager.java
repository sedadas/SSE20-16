package at.ac.tuwien.sse.owaspm5.manager;

public class OwnEncryptionManager implements IEncryptionManager {
    @Override
    public String encrypt(String data, String password) {
        char[] dataArray = data.toCharArray();
        char[] passwordArray = password.toCharArray();
        int[] cipherArray = new int[dataArray.length];

        // "Encode" the data
        for (int i = 0; i < dataArray.length; i++) {
            cipherArray[i] = dataArray[i] + passwordArray[i % passwordArray.length] + i;
        }

        // Convert to a string
        StringBuilder cipher = new StringBuilder();
        for (int i : cipherArray) {
            cipher.append(i).append("-");
        }
        cipher.substring(0, cipher.length() - 1);

        return cipher.toString();
    }

    @Override
    public String decrypt(String data, String password) {
        String[] dataArray = data.split("-");
        char[] passwordArray = password.toCharArray();
        int[] plainTextArray = new int[dataArray.length];

        // "Encode" the data
        for (int i = 0; i < dataArray.length; i++) {
            plainTextArray[i] = Integer.parseInt(dataArray[i]) - passwordArray[i % passwordArray.length] - i;
        }

        // Convert to a string
        StringBuilder plainText = new StringBuilder();
        for (int i : plainTextArray) {
            plainText.append((char)i);
        }
        plainText.substring(0, plainText.length() - 1);

        return plainText.toString();
    }
}
