package at.ac.tuwien.sse.owaspm5.manager;

public interface IEncryptionManager {
    /**
     * Encrypts a given string with the provided password.
     * @param data The data that should be encrypted.
     * @param password The password.
     * @return The encrypted data.
     */
    String encrypt(String data, String password);

    /**
     * Decrypts a given string with the provided password.
     * @param data The encrypted data that should be decrypted.
     * @param password The password.
     * @return The decrypted data.
     * @return
     */
    String decrypt(String data, String password);
}
