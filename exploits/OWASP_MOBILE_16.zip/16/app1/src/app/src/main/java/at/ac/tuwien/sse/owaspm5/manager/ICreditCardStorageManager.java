package at.ac.tuwien.sse.owaspm5.manager;

import at.ac.tuwien.sse.owaspm5.entities.CreditCardInfo;

public interface ICreditCardStorageManager {
    /**
     * Sets the encryption manager that should be used to en- and decrypt the credit card
     * information.
     * @param encryptionManager The encryption manager.
     */
    void setEncryptionManager(IEncryptionManager encryptionManager);

    /**
     * Saves the credit card information.
     * @param creditCardInfo The credit card information.
     * @param password The password used for the encryption.
     */
    void save(CreditCardInfo creditCardInfo, String password);

    /**
     * Loads the credit card information.
     * @param password The password used for the encryption.
     * @return The credit card information.
     */
    CreditCardInfo load(String password);

    /**
     * Deletes stored credit card information.
     */
    void delete();

    /**
     * Returns whether there are stored credit card information or not.
     * @return True if there are stored credit card information, false otherwise.
     */
    boolean hasStoredCreditCardInformation();
}
