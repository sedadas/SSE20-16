package at.ac.tuwien.sse.owaspm5.exceptions;

public class InternalStorageException extends Exception {
}
