package at.ac.tuwien.sse.owaspm5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import at.ac.tuwien.sse.owaspm5.entities.CreditCardInfo;
import at.ac.tuwien.sse.owaspm5.exceptions.InternalStorageException;
import at.ac.tuwien.sse.owaspm5.manager.ICreditCardStorageManager;
import at.ac.tuwien.sse.owaspm5.manager.IEncryptionManager;
import at.ac.tuwien.sse.owaspm5.manager.InternalCreditCardStorageManager;
import at.ac.tuwien.sse.owaspm5.manager.OwnEncryptionManager;

public class EnterCreditCardInformationActivity extends AppCompatActivity {

    private IEncryptionManager encryptionManager;
    private ICreditCardStorageManager creditCardStorageManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_credit_card_information);

        encryptionManager = new OwnEncryptionManager();

        try {
            creditCardStorageManager = new InternalCreditCardStorageManager(this);
        } catch (InternalStorageException internalStorageException) {
            this.finishAndRemoveTask();
        }
        creditCardStorageManager.setEncryptionManager(encryptionManager);

        final EditText editTextName = findViewById(R.id.etName);
        final EditText editTextNumber = findViewById(R.id.etNumber);
        final EditText editTextValidityDate = findViewById(R.id.etValidityDate);
        final EditText editTextSecurityCode = findViewById(R.id.etSecurityCode);
        final EditText editTextPassword = findViewById(R.id.etEncryptPassword);

        // If the 'Save'-button is pressed, the provided credit card information gets stored and the
        // MainActivity gets shown.
        Button buttonSave = findViewById(R.id.btnSave);
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreditCardInfo creditCardInfo = new CreditCardInfo(
                        editTextName.getText().toString(),
                        editTextNumber.getText().toString(),
                        editTextValidityDate.getText().toString(),
                        editTextSecurityCode.getText().toString());

                String password = editTextPassword.getText().toString();

                creditCardStorageManager.save(creditCardInfo, password);

                Intent intent = new Intent(EnterCreditCardInformationActivity.this, MainActivity.class);
                EnterCreditCardInformationActivity.this.startActivity(intent);
            }
        });
    }
}
