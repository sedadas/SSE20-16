package at.ac.tuwien.sse.owaspm5.manager;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.gson.Gson;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import at.ac.tuwien.sse.owaspm5.entities.CreditCardInfo;
import at.ac.tuwien.sse.owaspm5.exceptions.InternalStorageException;

public class InternalCreditCardStorageManager implements ICreditCardStorageManager {

    private static final String LOGGING_TAG = InternalCreditCardStorageManager.class.getName();

    private static final String PREFERENCES_FILE_KEY = "sp_owasp_m5";
    private static final String KEY_HAS_STORED_CREDIT_CARD_INFO = "hasStoredCreditCardInfo";

    private static final String CREDIT_CARD_INFO_FILE_NAME = "credit-card-file.txt";

    private File creditCardInfoFile;

    private IEncryptionManager encryptionManager;
    private SharedPreferences sharedPrefs;

    public InternalCreditCardStorageManager(Activity activity) throws InternalStorageException{
        sharedPrefs = activity.getSharedPreferences(PREFERENCES_FILE_KEY, Context.MODE_PRIVATE);

        File internalStorage = activity.getFilesDir();
        creditCardInfoFile = new File(internalStorage, CREDIT_CARD_INFO_FILE_NAME);
        if (!creditCardInfoFile.exists()) {
            try {
                this.creditCardInfoFile.createNewFile();
            } catch (IOException ioException) {
                Log.e(LOGGING_TAG, "Could not create credit card info file.");
                throw new InternalStorageException();
            }
        }
    }

    @Override
    public void setEncryptionManager(IEncryptionManager encryptionManager) {
        this.encryptionManager = encryptionManager;
    }

    @Override
    public void save(CreditCardInfo creditCardInfo, String password) {
        if (password == null || password.equals("")) {
            return;
        }

        Gson gson = new Gson();
        String json = gson.toJson(creditCardInfo, CreditCardInfo.class);

        String encryptedJson = encryptionManager.encrypt(json, password);
        writeToFile(encryptedJson);

        SharedPreferences.Editor editor = sharedPrefs.edit();
        editor.putBoolean(KEY_HAS_STORED_CREDIT_CARD_INFO, true);
        editor.commit();
    }

    @Override
    public CreditCardInfo load(String password) {
        if (password == null || password.equals("")) {
            return null;
        }

        Gson gson = new Gson();
        char[] buffer = new char[4096];

        try {
            FileReader fileReader = new FileReader(creditCardInfoFile);
            fileReader.read(buffer);
            fileReader.close();
        } catch (IOException ioException) {
            Log.e(LOGGING_TAG, "Could not read from credit card information file!");
        }

        String encryptedData = String.copyValueOf(buffer).trim();
        if (encryptedData.isEmpty()) {
            return null;
        }

        String json = encryptionManager.decrypt(encryptedData, password);
        try {
            return gson.fromJson(json, CreditCardInfo.class);
        } catch (Exception exception) {
            return null;
        }
    }

    @Override
    public void delete() {
        writeToFile("");

        SharedPreferences.Editor editor = sharedPrefs.edit();
        editor.clear();
        editor.commit();
    }

    @Override
    public boolean hasStoredCreditCardInformation() {
        return sharedPrefs.getBoolean(KEY_HAS_STORED_CREDIT_CARD_INFO, false);
    }

    /**
     * Writes data into the credit card information file.
     * @param data The text that should be written into the credit card information file.
     */
    private void writeToFile(String data) {
        try {
            FileWriter fileWriter = new FileWriter(creditCardInfoFile);
            fileWriter.write(data);
            fileWriter.close();
        } catch (IOException ex) {
            Log.e(LOGGING_TAG,"Could not write to credit card information file!");
        }
    }
}
