package at.ac.tuwien.sse.owaspm5.entities;

import androidx.annotation.NonNull;

public class CreditCardInfo {
    private String name;
    private String number;
    private String validityDate;
    private String code;

    public CreditCardInfo(String name,
                          String number,
                          String validityDate,
                          String code) {
        this.name = name;
        this.number = number;
        this.validityDate = validityDate;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getValidityDate() {
        return validityDate;
    }

    public void setValidityDate(String validityDate) {
        this.validityDate = validityDate;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @NonNull
    @Override
    public String toString() {
        return "Name: " + name +
                "\nNumber: " + number +
                "\nValid until (MM/YYYY): " + validityDate +
                "\nCode: " + code;
    }
}
