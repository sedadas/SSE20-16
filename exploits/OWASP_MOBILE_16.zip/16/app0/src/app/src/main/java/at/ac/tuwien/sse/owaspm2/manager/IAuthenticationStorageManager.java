package at.ac.tuwien.sse.owaspm2.manager;

import at.ac.tuwien.sse.owaspm2.entities.AuthenticationData;

public interface IAuthenticationStorageManager {
    /**
     * Saves the authentication information.
     * @param authenticationData The users authentication information.
     */
    void save(AuthenticationData authenticationData);

    /**
     * Loads stored authentication information.
     * @return Stored authentication information or null if none exists.
     */
    AuthenticationData load();

    /**
     * Deletes all stored authentication information.
     */
    void delete();
}
