package at.ac.tuwien.sse.owaspm2.exceptions;

public class ExternalStorageException extends Exception {
}
