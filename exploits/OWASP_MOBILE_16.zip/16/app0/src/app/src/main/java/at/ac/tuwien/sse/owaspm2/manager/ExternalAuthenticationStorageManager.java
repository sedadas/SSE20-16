package at.ac.tuwien.sse.owaspm2.manager;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.google.gson.Gson;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import at.ac.tuwien.sse.owaspm2.entities.AuthenticationData;
import at.ac.tuwien.sse.owaspm2.exceptions.ExternalStorageException;

public class ExternalAuthenticationStorageManager implements IAuthenticationStorageManager {

    private static final String LOGGING_TAG = ExternalAuthenticationStorageManager.class.getName();
    private static final String AUTH_DATA_FILE_NAME = "auth-data.json";
    private File authFile;

    public ExternalAuthenticationStorageManager(Activity activity) throws ExternalStorageException {
        if (!isExternalStorageWritable()) {
            Log.e(LOGGING_TAG,"Could not access external storage!");
            throw new ExternalStorageException();
        }

        File[] externalStorageVolumes =
                ContextCompat.getExternalFilesDirs(activity.getApplicationContext(), null);
        File primaryExternalStorage = externalStorageVolumes[0];

        this.authFile = new File(primaryExternalStorage, AUTH_DATA_FILE_NAME);
        if (!this.authFile.exists()) {
            try {
                this.authFile.createNewFile();
            } catch (IOException ioException) {
                Log.e(LOGGING_TAG,"Could create the authentication file!");
                throw new ExternalStorageException();
            }
        }
    }

    @Override
    public void save(AuthenticationData authenticationData) {
        Gson gson = new Gson();
        String json = gson.toJson(authenticationData, AuthenticationData.class);

        writeToFile(json);
    }

    @Override
    public AuthenticationData load() {
        Gson gson = new Gson();
        char[] buffer = new char[4096];

        try {
            FileReader fileReader = new FileReader(this.authFile);
            fileReader.read(buffer);
            fileReader.close();
        } catch (IOException ioException) {
            Log.e(LOGGING_TAG, "Could not read from authentication file!");
        }

        String json = String.copyValueOf(buffer).trim();
        if (json.isEmpty()) {
            return null;
        }

        return gson.fromJson(json, AuthenticationData.class);
    }

    @Override
    public void delete() {
        writeToFile("");
    }

    /**
     * Checks whether the external storage is available and writeable.
     * @return True if external storage is available and writeable, false otherwise.
     */
    private boolean isExternalStorageWritable() {
        return Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
    }

    /**
     * Writes data into the authentication file.
     * @param data The text that should be written into the authentication file.
     */
    private void writeToFile(String data) {
        try {
            FileWriter fileWriter = new FileWriter(this.authFile);
            fileWriter.write(data);
            fileWriter.close();
        } catch (IOException ex) {
            Log.e(LOGGING_TAG,"Could not write to authentication file!");
        }
    }
}
