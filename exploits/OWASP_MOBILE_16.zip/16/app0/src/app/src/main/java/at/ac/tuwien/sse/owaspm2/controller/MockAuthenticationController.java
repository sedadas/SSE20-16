package at.ac.tuwien.sse.owaspm2.controller;

import at.ac.tuwien.sse.owaspm2.entities.AuthenticationData;

public class MockAuthenticationController implements IAuthenticationController {

    private static final String MOCK_USERNAME = "sse";
    private static final String MOCK_PASSWORD = "topsecret";
    private static final String MOCK_SESSION = "xxxxx.yyyyy.zzzzz";

    private String session = null;

    @Override
    public boolean login(AuthenticationData authenticationData) {
        session = null;

        if (authenticationData == null
                || authenticationData.getUsername() == null
                || authenticationData.getPassword() == null) {
            return false;
        }

        if (authenticationData.getUsername().equals(MOCK_USERNAME)
                && authenticationData.getPassword().equals(MOCK_PASSWORD)) {
            session = MOCK_SESSION;
            return true;
        }

        return false;
    }

    @Override
    public boolean validateSession(AuthenticationData authenticationData) {
        if (authenticationData == null
                || authenticationData.getSession() == null) {
            return false;
        }

        return authenticationData.getSession().equals(MOCK_SESSION);
    }

    @Override
    public String getSession() {
        return session;
    }
}
