package at.ac.tuwien.sse.owaspm2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import at.ac.tuwien.sse.owaspm2.controller.IAuthenticationController;
import at.ac.tuwien.sse.owaspm2.controller.MockAuthenticationController;
import at.ac.tuwien.sse.owaspm2.entities.AuthenticationData;
import at.ac.tuwien.sse.owaspm2.exceptions.ExternalStorageException;
import at.ac.tuwien.sse.owaspm2.manager.ExternalAuthenticationStorageManager;
import at.ac.tuwien.sse.owaspm2.manager.IAuthenticationStorageManager;

public class MainActivity extends AppCompatActivity {

    private IAuthenticationController loginController;

    private IAuthenticationStorageManager authStorageManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Context context = this;

        loginController = new MockAuthenticationController();

        try {
            authStorageManager = new ExternalAuthenticationStorageManager(this);
        } catch (ExternalStorageException ex) {
            this.finishAndRemoveTask();
        }

        // Check if there are stored authentication information and try to perform a login.
        AuthenticationData authData = authStorageManager.load();
        if (loginController.login(authData)) {
            startLoggedInActivity(authData.getUsername());
        }

        final EditText editTextUsername = findViewById(R.id.etUsername);
        final EditText editTextPassword = findViewById(R.id.etPassword);
        final CheckBox checkBoxSaveCredentials = findViewById(R.id.cbSaveCredentials);

        // Try to log the user in if he or she presses the 'Login'-button
        Button buttonLogin = findViewById(R.id.btnLogin);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                AuthenticationData authenticationData = new AuthenticationData(username, password);

                if (!loginController.login(authenticationData)) {
                    Toast toast = Toast.makeText(context, "Wrong username or password!", Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }

                // Save the authentication information if the "Remember me!" checkbox is checked.
                if (checkBoxSaveCredentials.isChecked()) {
                    authStorageManager.save(authenticationData);
                }

                startLoggedInActivity(username);
            }
        });
    }

    /**
     * Starts the {@link LoggedInActivity}.
     * @param username The username.
     */
    private void startLoggedInActivity(String username) {
        Intent intent = new Intent(MainActivity.this, LoggedInActivity.class);
        intent.putExtra("Username", username);
        MainActivity.this.startActivity(intent);
    }
}
