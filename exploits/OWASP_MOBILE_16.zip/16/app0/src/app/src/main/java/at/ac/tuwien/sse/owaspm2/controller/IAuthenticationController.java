package at.ac.tuwien.sse.owaspm2.controller;

import at.ac.tuwien.sse.owaspm2.entities.AuthenticationData;

public interface IAuthenticationController {
    /**
     * Tries to login a username with the provided username and password.
     * @param authenticationData The users username and password.
     * @return True if the login could be performed, false otherwise.
     */
    boolean login(AuthenticationData authenticationData);

    /**
     * Checks if a provided session token is still valid.
     * @param authenticationData The users session token.
     * @return True if the token is still valid, false otherwise.
     */
    boolean validateSession(AuthenticationData authenticationData);

    /**
     * Returns the session token if a successful login was performed.
     * @return The session token.
     */
    String getSession();
}
